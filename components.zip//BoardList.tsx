import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState, useMemo } from 'react';

const boards = [
  { id: 'b', name: 'Random', description: 'Случайные темы', posts: 0 },
  { id: 'a', name: 'Аниме', description: 'Аниме и манга', posts: 0 },
  { id: 'v', name: 'Видеоигры', description: 'Обсуждение игр', posts: 0 },
  { id: 'tech', name: 'Технологии', description: 'IT и программирование', posts: 0 },
  { id: 'mu', name: 'Музыка', description: 'Музыка всех жанров', posts: 0 },
  { id: 'art', name: 'Искусство', description: 'Творчество и дизайн', posts: 0 },
  { id: 'ph', name: 'Философия', description: 'Философские дискуссии', posts: 0 },
  { id: 'lit', name: 'Литература', description: 'Книги и письменность', posts: 0 },
];

interface BoardListProps {
  searchQuery?: string;
}

export function BoardList({ searchQuery = '' }: BoardListProps) {
  const filteredBoards = useMemo(() => {
    if (!searchQuery.trim()) return boards;
    
    const query = searchQuery.toLowerCase();
    return boards.filter(board => 
      board.id.toLowerCase().includes(query) ||
      board.name.toLowerCase().includes(query) ||
      board.description.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  return (
    <div>
      <h2 className="mb-6 text-gray-100">
        Доски
      </h2>
      
      {filteredBoards.length === 0 ? (
        <div className="text-center py-12 text-gray-600">
          Доски не найдены
        </div>
      ) : (
        <div className="space-y-2">
          {filteredBoards.map((board) => (
            <Link
              key={board.id}
              to={`/${board.id}`}
              className="block border border-gray-800 rounded-lg p-5 hover:border-gray-700 hover:bg-gray-900/30 transition-colors group"
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <span className="text-gray-100">
                      /{board.id}/
                    </span>
                    <span className="text-gray-400">
                      {board.name}
                    </span>
                  </div>
                  <p className="text-gray-600">
                    {board.description}
                  </p>
                </div>
                
                <div className="flex items-center gap-4">
                  <span className="text-gray-600">
                    {board.posts.toLocaleString()} постов
                  </span>
                  <ChevronRight className="w-5 h-5 text-gray-700 group-hover:text-gray-500 transition-colors" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}