import { Activity, Image, MessageSquare } from 'lucide-react';

export function Stats() {
  return (
    <div className="grid grid-cols-3 gap-4 mb-12">
      <div className="border border-gray-800 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-2">
          <MessageSquare className="w-5 h-5 text-gray-500" />
          <span className="text-gray-500">Постов</span>
        </div>
        <p className="text-gray-100">0</p>
      </div>
      
      <div className="border border-gray-800 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-2">
          <Image className="w-5 h-5 text-gray-500" />
          <span className="text-gray-500">Изображений</span>
        </div>
        <p className="text-gray-100">0</p>
      </div>
      
      <div className="border border-gray-800 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-2">
          <Activity className="w-5 h-5 text-gray-500" />
          <span className="text-gray-500">Онлайн</span>
        </div>
        <p className="text-gray-100">0</p>
      </div>
    </div>
  );
}