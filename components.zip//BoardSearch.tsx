import { Search } from 'lucide-react';
import { useState } from 'react';

interface BoardSearchProps {
  onSearch?: (query: string) => void;
}

export function BoardSearch({ onSearch }: BoardSearchProps) {
  const [query, setQuery] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    if (onSearch) onSearch(value);
  };

  return (
    <div className="mb-8">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
        <input
          type="text"
          value={query}
          onChange={handleChange}
          placeholder="Поиск по доскам..."
          className="w-full bg-black border border-gray-800 rounded-lg pl-12 pr-4 py-3 text-gray-300 placeholder:text-gray-600 focus:outline-none focus:border-gray-700 transition-colors"
        />
      </div>
    </div>
  );
}