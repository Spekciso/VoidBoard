import { Newspaper, Sparkles, Plus, AlertCircle, Mail, Shield } from 'lucide-react';
import { useState } from 'react';
import { Modal } from './Modal';
import { NewsModal } from './modals/NewsModal';
import { UpdatesModal } from './modals/UpdatesModal';
import { CreateThreadModal } from './modals/CreateThreadModal';
import { ComplaintModal } from './modals/ComplaintModal';
import { ContactModal } from './modals/ContactModal';
import { ModeratorModal } from './modals/ModeratorModal';

export function Sidebar() {
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const menuItems = [
    { icon: Newspaper, label: 'Новости', modal: 'news' },
    { icon: Sparkles, label: 'Обновления', modal: 'updates' },
    { icon: Plus, label: 'Создать тред', modal: 'createThread' },
    { icon: AlertCircle, label: 'Подать жалобу', modal: 'complaint' },
    { icon: Mail, label: 'Связь с администратором', modal: 'contact' },
    { icon: Shield, label: 'Стать модератором', modal: 'moderator' },
  ];

  const handleClose = () => setActiveModal(null);

  return (
    <>
      <aside className="space-y-2">
        {menuItems.map((item, index) => (
          <button
            key={index}
            onClick={() => setActiveModal(item.modal)}
            className="w-full flex items-center gap-3 border border-gray-800 rounded-lg px-4 py-3 hover:border-gray-700 hover:bg-gray-900/30 transition-colors text-gray-400 hover:text-gray-300"
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </button>
        ))}
      </aside>

      <Modal isOpen={activeModal === 'news'} onClose={handleClose} title="Новости">
        <NewsModal />
      </Modal>

      <Modal isOpen={activeModal === 'updates'} onClose={handleClose} title="Обновления">
        <UpdatesModal />
      </Modal>

      <Modal isOpen={activeModal === 'createThread'} onClose={handleClose} title="Создать тред">
        <CreateThreadModal onSubmit={handleClose} />
      </Modal>

      <Modal isOpen={activeModal === 'complaint'} onClose={handleClose} title="Подать жалобу">
        <ComplaintModal onSubmit={handleClose} />
      </Modal>

      <Modal isOpen={activeModal === 'contact'} onClose={handleClose} title="Связь с администратором">
        <ContactModal onSubmit={handleClose} />
      </Modal>

      <Modal isOpen={activeModal === 'moderator'} onClose={handleClose} title="Стать модератором">
        <ModeratorModal onSubmit={handleClose} />
      </Modal>
    </>
  );
}