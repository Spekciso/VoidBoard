import { useState } from 'react';
import { Modal } from './Modal';
import { FaqModal } from './modals/FaqModal';

export function Header() {
  const [isFaqOpen, setIsFaqOpen] = useState(false);

  return (
    <>
      <header className="border-b border-gray-800 py-6">
        <div className="max-w-7xl mx-auto px-6 flex items-start justify-between">
          <div>
            <h1 className="text-gray-100">
              VOID
            </h1>
            <p className="text-gray-500 mt-2">
              Анонимный имиджборд
            </p>
          </div>
          
          <button 
            onClick={() => setIsFaqOpen(true)}
            className="border border-gray-800 px-4 py-2 rounded-lg hover:border-gray-700 hover:bg-gray-900/30 transition-colors text-gray-400 hover:text-gray-300"
          >
            FAQ
          </button>
        </div>
      </header>

      <Modal isOpen={isFaqOpen} onClose={() => setIsFaqOpen(false)} title="FAQ">
        <FaqModal />
      </Modal>
    </>
  );
}