import { useState } from 'react';

export function ContactModal({ onSubmit }: { onSubmit?: () => void }) {
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Sending message:', { email, subject, message });
    if (onSubmit) onSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <p className="text-gray-500">
        Свяжитесь с администрацией по вопросам работы имиджборда.
      </p>

      <div>
        <label htmlFor="email" className="block text-gray-400 mb-2">
          Email для ответа
        </label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          placeholder="your@email.com"
          required
        />
      </div>

      <div>
        <label htmlFor="subject" className="block text-gray-400 mb-2">
          Тема
        </label>
        <input
          id="subject"
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          placeholder="Тема обращения"
          required
        />
      </div>

      <div>
        <label htmlFor="message" className="block text-gray-400 mb-2">
          Сообщение
        </label>
        <textarea
          id="message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={6}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors resize-none"
          placeholder="Опишите ваш вопрос или предложение..."
          required
        />
      </div>

      <button
        type="submit"
        className="w-full bg-gray-100 text-black rounded-lg px-6 py-3 hover:bg-white transition-colors"
      >
        Отправить сообщение
      </button>
    </form>
  );
}
