import { useState } from 'react';

export function ComplaintModal({ onSubmit }: { onSubmit?: () => void }) {
  const [url, setUrl] = useState('');
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Submitting complaint:', { url, reason, description });
    if (onSubmit) onSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <p className="text-gray-500">
        Используйте эту форму для жалоб на нарушения правил имиджборда.
      </p>

      <div>
        <label htmlFor="url" className="block text-gray-400 mb-2">
          Ссылка на пост
        </label>
        <input
          id="url"
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          placeholder="https://void.example/b/12345"
          required
        />
      </div>

      <div>
        <label htmlFor="reason" className="block text-gray-400 mb-2">
          Причина жалобы
        </label>
        <select
          id="reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          required
        >
          <option value="">Выберите причину...</option>
          <option value="spam">Спам</option>
          <option value="illegal">Незаконный контент</option>
          <option value="personal">Личная информация</option>
          <option value="harassment">Оскорбления/Харассмент</option>
          <option value="offtopic">Оффтопик</option>
          <option value="other">Другое</option>
        </select>
      </div>

      <div>
        <label htmlFor="description" className="block text-gray-400 mb-2">
          Описание
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors resize-none"
          placeholder="Опишите подробности нарушения..."
          required
        />
      </div>

      <button
        type="submit"
        className="w-full bg-gray-100 text-black rounded-lg px-6 py-3 hover:bg-white transition-colors"
      >
        Отправить жалобу
      </button>
    </form>
  );
}
