import { useState } from 'react';
import { Upload } from 'lucide-react';

interface CreateThreadModalProps {
  boardId?: string;
  onSubmit?: () => void;
}

export function CreateThreadModal({ boardId, onSubmit }: CreateThreadModalProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [fileName, setFileName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // В реальном приложении здесь была бы отправка на сервер
    console.log('Creating thread:', { title, content, boardId });
    if (onSubmit) onSubmit();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {boardId && (
        <div className="text-gray-500">
          Доска: <span className="text-gray-300">/{boardId}/</span>
        </div>
      )}
      
      <div>
        <label htmlFor="title" className="block text-gray-400 mb-2">
          Заголовок
        </label>
        <input
          id="title"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          placeholder="Введите заголовок треда..."
          required
        />
      </div>

      <div>
        <label htmlFor="content" className="block text-gray-400 mb-2">
          Текст
        </label>
        <textarea
          id="content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={6}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors resize-none"
          placeholder="Введите текст сообщения..."
          required
        />
      </div>

      <div>
        <label className="block text-gray-400 mb-2">
          Изображение (необязательно)
        </label>
        <label className="block border border-gray-800 rounded-lg px-4 py-3 hover:border-gray-700 transition-colors cursor-pointer">
          <div className="flex items-center gap-3">
            <Upload className="w-5 h-5 text-gray-600" />
            <span className="text-gray-500">
              {fileName || 'Выберите файл...'}
            </span>
          </div>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </label>
      </div>

      <button
        type="submit"
        className="w-full bg-gray-100 text-black rounded-lg px-6 py-3 hover:bg-white transition-colors"
      >
        Создать тред
      </button>
    </form>
  );
}
