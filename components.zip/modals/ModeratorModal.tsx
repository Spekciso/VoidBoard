import { useState } from 'react';

export function ModeratorModal({ onSubmit }: { onSubmit?: () => void }) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [experience, setExperience] = useState('');
  const [motivation, setMotivation] = useState('');
  const [availability, setAvailability] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Submitting moderator application:', { username, email, experience, motivation, availability });
    if (onSubmit) onSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <p className="text-gray-500">
        Заполните заявку на должность модератора. Мы рассмотрим вашу кандидатуру и свяжемся с вами.
      </p>

      <div>
        <label htmlFor="username" className="block text-gray-400 mb-2">
          Имя пользователя
        </label>
        <input
          id="username"
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          placeholder="Ваш ник"
          required
        />
      </div>

      <div>
        <label htmlFor="email" className="block text-gray-400 mb-2">
          Email
        </label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          placeholder="your@email.com"
          required
        />
      </div>

      <div>
        <label htmlFor="availability" className="block text-gray-400 mb-2">
          Доступность
        </label>
        <select
          id="availability"
          value={availability}
          onChange={(e) => setAvailability(e.target.value)}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors"
          required
        >
          <option value="">Выберите...</option>
          <option value="1-3">1-3 часа в день</option>
          <option value="3-5">3-5 часов в день</option>
          <option value="5+">Более 5 часов в день</option>
        </select>
      </div>

      <div>
        <label htmlFor="experience" className="block text-gray-400 mb-2">
          Опыт модерации
        </label>
        <textarea
          id="experience"
          value={experience}
          onChange={(e) => setExperience(e.target.value)}
          rows={3}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors resize-none"
          placeholder="Опишите ваш опыт модерации на других платформах..."
          required
        />
      </div>

      <div>
        <label htmlFor="motivation" className="block text-gray-400 mb-2">
          Почему вы хотите стать модератором?
        </label>
        <textarea
          id="motivation"
          value={motivation}
          onChange={(e) => setMotivation(e.target.value)}
          rows={4}
          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors resize-none"
          placeholder="Расскажите о вашей мотивации..."
          required
        />
      </div>

      <button
        type="submit"
        className="w-full bg-gray-100 text-black rounded-lg px-6 py-3 hover:bg-white transition-colors"
      >
        Подать заявку
      </button>
    </form>
  );
}
