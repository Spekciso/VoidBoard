const news = [
];

export function NewsModal() {
  return (
    <div className="space-y-6">
      {news.length === 0 ? (
        <div className="text-center py-12 text-gray-600">
          Пока нет новостей
        </div>
      ) : (
        news.map((item, index) => (
          <div key={index} className="border-b border-gray-800 pb-6 last:border-0">
            <div className="text-gray-600 mb-2">{item.date}</div>
            <h3 className="text-gray-100 mb-2">{item.title}</h3>
            <p className="text-gray-500">{item.content}</p>
          </div>
        ))
      )}
    </div>
  );
}