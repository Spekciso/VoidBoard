const updates = [
];

export function UpdatesModal() {
  return (
    <div className="space-y-6">
      {updates.length === 0 ? (
        <div className="text-center py-12 text-gray-600">
          Пока нет обновлений
        </div>
      ) : (
        updates.map((update, index) => (
          <div key={index} className="border-b border-gray-800 pb-6 last:border-0">
            <div className="flex items-center gap-3 mb-3">
              <span className="text-gray-100">{update.version}</span>
              <span className="text-gray-600">{update.date}</span>
            </div>
            <ul className="space-y-2">
              {update.changes.map((change, i) => (
                <li key={i} className="text-gray-500 pl-4 relative before:content-['•'] before:absolute before:left-0">
                  {change}
                </li>
              ))}
            </ul>
          </div>
        ))
      )}
    </div>
  );
}