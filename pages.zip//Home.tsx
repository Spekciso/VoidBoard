import { BoardList } from '../components/BoardList';
import { Header } from '../components/Header';
import { Stats } from '../components/Stats';
import { Sidebar } from '../components/Sidebar';
import { BoardSearch } from '../components/BoardSearch';
import { useState } from 'react';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-black text-gray-300">
      <Header />
      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex gap-8">
          <div className="flex-1">
            <Stats />
            <BoardSearch onSearch={setSearchQuery} />
            <BoardList searchQuery={searchQuery} />
          </div>
          <div className="w-[300px] flex-shrink-0">
            <Sidebar />
          </div>
        </div>
      </main>
    </div>
  );
}