import { useParams, Link } from 'react-router';
import { ArrowLeft, Image as ImageIcon } from 'lucide-react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { useState } from 'react';

const mockPosts = [
];

export default function Thread() {
  const { boardId, threadId } = useParams();
  const [replyText, setReplyText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Posting reply:', replyText);
    setReplyText('');
  };

  return (
    <div className="min-h-screen bg-black text-gray-300">
      <Header />
      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex gap-8">
          <div className="flex-1">
            {/* Thread Header */}
            <div className="mb-8">
              <Link
                to={`/${boardId}`}
                className="inline-flex items-center gap-2 text-gray-500 hover:text-gray-400 mb-4 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Назад к доске /{boardId}/
              </Link>
              
              <h1 className="text-gray-100 mb-2">
                Тред #{threadId}
              </h1>
            </div>

            {/* Posts */}
            {mockPosts.length === 0 ? (
              <div className="text-center py-12 border border-gray-800 rounded-lg mb-8">
                <p className="text-gray-600">Тред не найден или удален</p>
              </div>
            ) : (
              <div className="space-y-4 mb-8">
                {mockPosts.map((post) => (
                  <div
                    key={post.id}
                    className={`border rounded-lg p-6 ${
                      post.isOP 
                        ? 'border-gray-700 bg-gray-900/30' 
                        : 'border-gray-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <span className="text-gray-400">{post.author}</span>
                        {post.isOP && (
                          <span className="text-xs bg-gray-800 text-gray-400 px-2 py-1 rounded">
                            OP
                          </span>
                        )}
                        <span className="text-gray-600">#{post.number}</span>
                      </div>
                      <span className="text-gray-600">{post.timestamp}</span>
                    </div>
                    <p className="text-gray-300">{post.content}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Reply Form */}
            <div className="border border-gray-800 rounded-lg p-6">
              <h3 className="text-gray-100 mb-4">
                Ответить в тред
              </h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <textarea
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  rows={4}
                  className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-gray-700 transition-colors resize-none"
                  placeholder="Введите ваш ответ..."
                  required
                />
                
                <div className="flex items-center gap-4">
                  <label className="border border-gray-800 rounded-lg px-4 py-2 hover:border-gray-700 transition-colors cursor-pointer text-gray-400 hover:text-gray-300">
                    <div className="flex items-center gap-2">
                      <ImageIcon className="w-4 h-4" />
                      <span>Добавить изображение</span>
                    </div>
                    <input type="file" accept="image/*" className="hidden" />
                  </label>
                  
                  <button
                    type="submit"
                    className="ml-auto bg-gray-100 text-black rounded-lg px-6 py-2 hover:bg-white transition-colors"
                  >
                    Отправить
                  </button>
                </div>
              </form>
            </div>
          </div>
          
          <div className="w-[300px] flex-shrink-0">
            <Sidebar />
          </div>
        </div>
      </main>
    </div>
  );
}