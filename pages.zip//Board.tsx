import { useParams, Link } from 'react-router';
import { ArrowLeft, Pin, MessageSquare, Image } from 'lucide-react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { useState } from 'react';
import { Modal } from '../components/Modal';
import { CreateThreadModal } from '../components/modals/CreateThreadModal';

const boardInfo: Record<string, { name: string; description: string }> = {
  b: { name: 'Random', description: 'Случайные темы' },
  a: { name: 'Аниме', description: 'Аниме и манга' },
  v: { name: 'Видеоигры', description: 'Обсуждение игр' },
  tech: { name: 'Технологии', description: 'IT и программирование' },
  mu: { name: 'Музыка', description: 'Музыка всех жанров' },
  art: { name: 'Искусство', description: 'Творчество и дизайн' },
  ph: { name: 'Философия', description: 'Философские дискуссии' },
  lit: { name: 'Литература', description: 'Книги и письменность' },
};

const mockThreads = [
];

export default function Board() {
  const { boardId } = useParams();
  const board = boardInfo[boardId || ''] || { name: 'Неизвестная доска', description: '' };
  const [isCreateThreadOpen, setIsCreateThreadOpen] = useState(false);

  return (
    <div className="min-h-screen bg-black text-gray-300">
      <Header />
      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex gap-8">
          <div className="flex-1">
            {/* Board Header */}
            <div className="mb-8">
              <Link
                to="/"
                className="inline-flex items-center gap-2 text-gray-500 hover:text-gray-400 mb-4 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Назад к доскам
              </Link>
              
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-gray-100">
                  /{boardId}/
                </h1>
                <span className="text-gray-400">{board.name}</span>
              </div>
              <p className="text-gray-600">{board.description}</p>
            </div>

            {/* Create Thread Button */}
            <button 
              onClick={() => setIsCreateThreadOpen(true)}
              className="w-full border border-gray-800 rounded-lg px-6 py-4 mb-6 hover:border-gray-700 hover:bg-gray-900/30 transition-colors text-gray-400 hover:text-gray-300"
            >
              + Создать новый тред
            </button>

            {/* Threads List */}
            {mockThreads.length === 0 ? (
              <div className="text-center py-12 border border-gray-800 rounded-lg">
                <p className="text-gray-600">Пока нет тредов на этой доске</p>
                <p className="text-gray-700 mt-2">Будьте первым, кто создаст тред!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {mockThreads.map((thread) => (
                  <Link
                    key={thread.id}
                    to={`/${boardId}/${thread.id}`}
                    className="block border border-gray-800 rounded-lg p-6 hover:border-gray-700 hover:bg-gray-900/30 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {thread.isPinned && (
                          <Pin className="w-4 h-4 text-gray-500" />
                        )}
                        <h3 className="text-gray-100">
                          {thread.title}
                        </h3>
                      </div>
                      <span className="text-gray-600">
                        {thread.timestamp}
                      </span>
                    </div>
                    
                    <p className="text-gray-500 mb-4">
                      {thread.content}
                    </p>
                    
                    <div className="flex items-center gap-6 text-gray-600">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4" />
                        <span>{thread.replies} ответов</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Image className="w-4 h-4" />
                        <span>{thread.images} изображений</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
          
          <div className="w-[300px] flex-shrink-0">
            <Sidebar />
          </div>
        </div>
      </main>

      <Modal 
        isOpen={isCreateThreadOpen} 
        onClose={() => setIsCreateThreadOpen(false)} 
        title="Создать тред"
      >
        <CreateThreadModal 
          boardId={boardId} 
          onSubmit={() => setIsCreateThreadOpen(false)} 
        />
      </Modal>
    </div>
  );
}